from django.shortcuts import render
from . import models
from django.db.models import Count
import sys
# Create your views here.
def index(req):
    countries_all = models.Countries.objects.all()
    cities_all = models.Cities.objects.all()
    languages_all = models.Languages.objects.all()
    languages = models.Languages.objects.filter(language='slovene')
    slovene = languages.order_by('-percentage')
#    countries_cities = countries_all.count()
    c = countries_all.filter()
    #1.
    print (50*"*")
    for i in range(0, len(slovene)):
        print (slovene[i].country.name)
    print (50*"*")
    print str(c[0].code) + ' ' +  c[0].name

    #2.
    print (50*"*")
    count_cities = models.Countries.objects.annotate(num_cities = Count('citytocountry')).order_by('-num_cities')[:len(countries_all)]
    for i in range(0, len(count_cities)):
        print (count_cities[i].name.encode(sys.stdout.encoding, errors='replace') + ' '+ str(count_cities[i].num_cities))

    #3.
    print (50*"*")
#    print str(countries_all.filter(name = 'Mexico')[0].id)+ ' '+ countries_all.filter(name = 'Mexico')[0].name
#    This tells me mexico is Id #136
    cities_mex = cities_all.filter(country = 136).order_by('-population')
    for i in range (0,len(cities_mex)):
        if cities_mex[i].population > 500000:
            print (cities_mex[i].name.encode(sys.stdout.encoding, errors='replace') + ' '+str(cities_mex[i].population))
        else:
            break

    #4.
    print (50*"*")
    language_per = languages_all.order_by('-percentage')
    for i in range(0,len(language_per)):
        if language_per[i].percentage > 89:
            print (language_per[i].country.name.encode(sys.stdout.encoding, errors='replace') + ' | '+ language_per[i].language.encode(sys.stdout.encoding, errors='replace')+ ' '+ str(language_per[i].percentage)+'%')
        else:
            break

    #5.
    print (50*"*")
    for i in range(0, len(countries_all)):
        if countries_all[i].surface_area < 501:
            if countries_all[i].population > 100000:
                print countries_all[i].name.encode(sys.stdout.encoding, errors='replace')+ ' '+ str(countries_all[i].surface_area) + ' ' + str(countries_all[i].population)
            else:
                pass
        else:
            pass
    #6.
    print (50*"*")
    for i in range(0, len(countries_all)):
        if countries_all[i].government_form == 'Constitutional Monarchy':
            if countries_all[i].capital> 200:
                if countries_all[i].life_expectancy > 75:
                    print countries_all[i].name + ' Life Expectancy: '+ str(countries_all[i].life_expectancy) + ' Capital: '+ str(countries_all[i].capital) + ' Government Form: ' + countries_all[i].government_form

    #7.
    print (50*"*")
#    print str(countries_all.filter(name = 'Argentina')[0].id)+ ' '+ countries_all.filter(name = 'Argentina')[0].name
#   This query tells me Argentina is id 9
    cities_argentina = cities_all.filter(country = 9).filter(district = 'Buenos Aires').order_by('-population')
    for i in range(0, len(cities_argentina)):
        if cities_argentina[i].population > 500000:
            print cities_argentina[i].country.name.encode(sys.stdout.encoding, errors='replace') + ' | ' +  cities_argentina[i].district.encode(sys.stdout.encoding, errors='replace') + ' | ' + cities_argentina[i].name.encode(sys.stdout.encoding, errors='replace') + ' | ' + str(cities_argentina[i].population)

    #8.
    print (50*"*")
#    region_coun = countries_all.annotate(region_count = Count('region'))
#    x = 0
#    for i in range(0 , len(region_coun)):
#        x += region_coun[i].region_count
#        print x
#   This tells me there are 239 regions in the database

    count_region = models.Countries.objects.values('region').annotate(num_countries = Count('region')).order_by('-num_countries')
    for i in range(0, len(count_region)):
        print 'Region: ' + count_region[i]['region'] + ' | Countries: ' + str(count_region[i]['num_countries']) 


    # Raw querries are slower than the ORM because you are using built in functions
    return render(req, 'worldApp/index.html', context={'cities':slovene})
