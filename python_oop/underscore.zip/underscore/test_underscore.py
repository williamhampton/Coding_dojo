import unittest
from underscore import Underscore

class UnderscoreTest(unittest.TestCase):
    def setUp(self):
        # create an instance of the Underscore module we created
        self._ = Underscore()
        # initialize a list to run our tests on
        self.test_list = [1,2,3,4,5]
    def testMap(self):
        pass
    def testReduce(self):
        pass
    def testFind(self):
        pass
    def testFilter(self):
        pass
    def testReject(self):
        pass

if __name__ == "__main__":
    unittest.main()
